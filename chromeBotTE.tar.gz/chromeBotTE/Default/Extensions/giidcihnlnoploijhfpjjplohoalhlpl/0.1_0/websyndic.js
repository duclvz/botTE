document.onreadystatechange = function() {
    if (document.readyState == "complete") {
        document.getElementsByClassName('titre_12')[1].getElementsByTagName('a')[0].click()
    }
}
