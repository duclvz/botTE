var myWindow = this.window;

window.addEventListener('load', function(){
    myWindow = window.open();
    myWindow.focus();
}, false);

window.addEventListener('pagehide', function(){
    myWindow.close();
}, false);