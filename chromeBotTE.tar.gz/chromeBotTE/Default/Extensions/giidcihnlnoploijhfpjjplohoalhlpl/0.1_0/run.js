var myWindow = this.window;
document.onreadystatechange = function() {
    if (document.readyState == "complete") {
        myWindow = window.open();
    	myWindow.focus();
    }
}

window.addEventListener('pagehide', function(){
    myWindow.close();
}, false);