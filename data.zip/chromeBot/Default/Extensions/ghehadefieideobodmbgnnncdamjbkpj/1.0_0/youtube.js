// var newtab = this.window;

window.addEventListener('load', function(){
	// setTimeout(function() {
	// 	newtab = window.open();
 //    	newtab.focus();
	// }, 2000)
	document.body.innerHTML="";
}, false);

// window.addEventListener('pagehide', function(){
//     newtab.close();
// }, false);