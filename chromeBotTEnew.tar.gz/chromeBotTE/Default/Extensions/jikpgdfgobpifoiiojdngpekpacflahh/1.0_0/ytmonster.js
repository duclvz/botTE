document.onreadystatechange = function() {
    if (document.readyState == "complete") {
        if (window.location.href.indexOf("ytmonster.net/login") > -1) {
            $.getJSON(chrome.extension.getURL('account.json'), function(json) {
                document.getElementsByName('usernames')[0].value = json.ytmonster.account;
                document.getElementsByName('passwords')[0].value = json.ytmonster.password;
                if (!(json.ytmonster.account=='ytmacc'||json.ytmonster.password=='ytmpass'))
                    document.getElementsByName('submit')[0].click()
            });
        }
        if (window.location.href.indexOf("ytmonster.net/dashboard") > -1) {
            window.open('/client.php', '_self')
        }
        if (window.location.href.indexOf("ytmonster.net/client") > -1) {
            document.getElementById('startBtn').click()
        }
    }
}